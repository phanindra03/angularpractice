import {Component, Output,EventEmitter} from '@angular/core';

@Component({

    selector:'child-app',
    templateUrl:'./app.child.html',
})
export class Child{
@Output() notify:EventEmitter<string>=new EventEmitter<string>();
onclick():void{
    this.notify.emit("phani");
}
}


