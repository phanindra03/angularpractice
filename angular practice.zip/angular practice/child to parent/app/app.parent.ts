import {Component} from '@angular/core';

@Component({

    selector:'parent-app',
    templateUrl:'./app.parent.html',
})
export class Parent{
   
oncall(message:string):void{

    alert(message);
}
}

