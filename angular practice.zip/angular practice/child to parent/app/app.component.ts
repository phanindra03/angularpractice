import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>this is  {{name}}.</h1><br/><parent-app></parent-app>`,
})
export class AppComponent  { name = 'app component'; }
