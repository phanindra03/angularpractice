
import {Flight} from './flight';
import {Component} from '@angular/core';
import {OnInit} from '@angular/core';
import {FlightService} from './flightservice';

@Component({
    selector:'flightdetails',
    templateUrl:'./flightdetails.html',
    providers:[FlightService]
})
export class FlightDetails implements OnInit{
    flights:Flight[];
    constructor(private service:FlightService){

    }
    ngOnInit():void{
        this.flights=this.service.flightrecord();
    }

}