"use strict";
var Flight = (function () {
    function Flight() {
    }
    return Flight;
}());
exports.Flight = Flight;
//# sourceMappingURL=flight.js.map