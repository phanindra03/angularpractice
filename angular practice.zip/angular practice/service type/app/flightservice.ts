import { Injectable } from "@angular/core";
import {Flight} from "./flight";
@Injectable()
export class FlightService{
    flightrecord():Flight[]{
        return [
            {flightName:"eti005",flightNumber:784512,flightDestination:"tokyo"},
            {flightName:"eti005",flightNumber:784338,flightDestination:"newyork"},
            {flightName:"eti006",flightNumber:784963,flightDestination:"washington"},
            {flightName:"eti007",flightNumber:784112,flightDestination:"hongkong"}
        ];

    }

}