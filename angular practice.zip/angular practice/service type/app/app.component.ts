import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1 align="center">Latest Flight Details of {{name}} Airways.</h1><br/><flightdetails></flightdetails>`,
})
export class AppComponent  {name="eithiad" ; }
