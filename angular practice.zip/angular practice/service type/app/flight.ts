export class Flight{
    flightName:string;
    flightNumber:number;
    flightDestination:string;

}