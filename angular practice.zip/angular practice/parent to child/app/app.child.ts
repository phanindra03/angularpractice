import { Component,Input} from '@angular/core';

@Component({
  selector: 'child-app',
  templateUrl: './app.child.html',
})
export class Child  {
    @Input() title:string;


 }