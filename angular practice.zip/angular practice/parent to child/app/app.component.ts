import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>This is {{name}}<br/><parent-app></parent-app></h1>`,
})
export class AppComponent  { name = 'appcomponent'; }
