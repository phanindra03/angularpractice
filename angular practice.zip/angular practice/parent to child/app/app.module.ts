import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {Parent} from './app.parent';
import {Child} from './app.child';
import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,Parent,Child ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
