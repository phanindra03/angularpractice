import { Component } from '@angular/core';

@Component({
  selector: 'parent-app',
  templateUrl: './app.parent.html',
})
export class Parent  { 
    childtitle:string="data in parent component";
 }