import {Component} from '@angular/core';
@Component({
    selector:'form1',
    templateUrl:'./app.form1.html',
})
export class Form1{
    flightName:string;
    flightNum:number;
    flightRoute:string;
    flightCost:number;
    flightClass:string;
}