import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1> {{name}}</h1><br/><form1></form1>`,
})
export class AppComponent  { 
  name = 'FORM1';
}
