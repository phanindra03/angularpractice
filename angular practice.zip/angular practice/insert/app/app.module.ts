import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule} from '@angular/forms';
import {Form1} from './app.form1';
import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule ,FormsModule],
  declarations: [ AppComponent,Form1 ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
